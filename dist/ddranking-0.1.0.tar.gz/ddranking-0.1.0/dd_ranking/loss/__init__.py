from .kl import KLDivergenceLoss
from .sce import SoftCrossEntropyLoss
