from .general import GeneralEvaluator
from .soft_label import SoftLabelEvaluator
from .hard_label import HardLabelEvaluator
